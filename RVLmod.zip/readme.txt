####  #####   #   #   #  ###  #     #####       #     ##### #   # #####
#   # #        #  #   # #   # #       #         #       #   #   # #
####  ###   ##### #   # #   # #       #         #       #   #   # ###
#  #  #      #     # #  #   # #       #         #       #    # #  #
#   # #####   #     #    ###  #####   #         ##### #####   #   #####

GFX and Models repaint v1.5.2 by ElectricBee

Content summary:
   New GFX <1.5.2>
      intros <Release>
         RVL
         Acclaim + Acclaim Studios
         Re-Volt Modified
      Font with blue position numerals <Release>
      Blue directional arrows <Release>
      Blue clone pickup and GSP icons <1.1>
      Blue firework icons <1.5>
         32-bit depth restored <1.5.1>
      Blue lasers / Fireworks discharge and sparks [VaiDuX461] <1.1>
   New models
      Fixed stock go3 [jigebren] <Release>
      Fireworks <1.5.2>
      RVL countdown and pickup models V1
         Pickups <Release -> 1.5>
         Go* <Release -> 1.5>
      RVL countdown and pickup models V2
         Pickups <1.5>
         Go* <1.5>
   Misc. files
      Blue Re-Volt icon for app shortcuts <Release>
      Internet shortcut to forum thread <1.1>
      Internet shortcut to ElectricBee's Aerials <v1.5.2>

To use, simply extract the contents of either V1 or V2 into the root directory. Each variation contains a diffrent appearance for everything, save for fireworks, bitmap texture and intro screens. Refer to the forum thread for more information and updates!

If you see you don't like it, I made certain all this awesome work can be undone, just by copying the entirety of the contents within the stock folder.

The URL files should not be malicious, but always double-check with a sandboxed web browser, or in a guest OS session running either on a physical or virtual machine.

Also, WeGo Interactive suck. If you see this work in their name, do everything you can to take it down as they have absolutely NO permission by me to use this for anything, for any reason... not like they can figure out how to include it.

Changelog:
Release; ADD original RVL countdown and pickups, in /models
         ADD original GFX with new blue item icons, in /gfx
         ADD stock items, in /Stock
    1.1; ADD firework model, in /models
         ADD modified GFX for blue lasers and firework emitters, in /gfx
         ADD stock firework model, in /Stock
    1.5; ADD "Version 2" of RVL countdown and pickups, in /V2/models
         MOVE Recreated "Version 1" of RVL countdown and pickups, from /models to /V1/models
  1.5.1; ADD 32-bit BMP depth for FxPage2 -- Dug it from the trash and changed fireworks there, since GIMP 2.6 supports transparent BMPs. [edit]
  1.5.2: CHANGE Firework to have no mapping on the firework body. Looks okay in lighted areas.
         MOVE gfx away from main of archive, into V1 and V2 for easier drag-and-drop
         CHANGE gfx to be compatible with stock aerials only, and reflect new fireworks
         ADD URL file to ElectricBee's Aerials for users of IBA to have something that works more-or-less like IBA.